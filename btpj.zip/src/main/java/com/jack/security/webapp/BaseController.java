package com.jack.security.webapp;

import com.jack.utils.Pager;

/**
 * Created by wajiangk on 9/23/2016.
 */
public class BaseController {

//    protected int f_page = 0;//分页显示第一个页码
//    protected int l_page = 0;//分页显示最后一个页码
//
//    public  void getFirstandLastPn(Pager pager){
//        if (pager.getPageNumber() < 5) {
//            f_page = 1;
//        } else {
//            f_page = pager.getPageNumber() - 3;
//        }
//        if (pager.getPageNumber() + 3 >= pager.getPageCount()) {
//            l_page = pager.getPageCount();
//        } else {
//            l_page = pager.getPageNumber() + 3;
//        }
//
//    }
}
