package com.jack.utils;

/**
 * Created by wajiangk on 9/5/2016.
 */
public interface SecurityConstants {

    String LOGIN_USER ="securityUser";

    String OPERATION_VIEW = "view";
    String OPERATION_SAVE = "save";
    String OPERATION_EDIT = "edit";
    String OPERATION_DELETE = "delete";


}
